<?php include('header.php');?>
<!--content-->
	<div class="contact">	
		<div class="container">
			<div class="contact-form">
				<h1>ตรวจสอบการจัดส่งสินค้า</h1>
				<!-- <div class="col-md-8 contact-grid">
				<?=$company_map;?>
						</div> --> 
				<center><iframe src="https://jtexpress.thaiware.com/" frameborder="0" allowtransparency="yes" scrolling="no" style="width:100%; height:800px; position:relative; left:-20px;top:100px;margin:50;padding:0;" ></iframe></center>
										
				<div class="clearfix"> </div>
			</div>	
		</div>
	</div><br>
 	<?php include('footer.php');?>