<?php include('header.php');?>

	
<!--content-->
<div class="contact">
			
			<div class="container">
				<h1><font color='#FF6600'</font>วิธีสั่งซื้อและชำระเงิน</h1>
				<br>
				<p><center><img src="../../upload/backpack.png"</center></p>
			<div class="contact-form">
				<!-- <div class="col-md-8 contact-grid">
					 <?=$company_map;?>
				</div> -->
				<div class="col-12 bg-rectangle color-blue  font-weight-bold">
                        <div class="booking-topic text-center"><h4><font color='#000000'</font></h4></div>
                        <br>
                        <div class="col-12 px-0 my-3">
                        	<div class="row justify-content-center text-center">
                            	<div class="col-12 col-md-4 my-3">
                                	<img src="../../images/login .png" width="150" height="150" class="img-fluid">
                                    <h3>ขั้นตอน 1</h3><br>
                                    <h4>สมัครสมาชิก และทำการ Log in เข้าสู่ระบบ</h4> </div>
                            	<div class="col-12 col-md-4 my-3">
                                	<img src="../../images/buy.png"  width="150" height="150"class="img-fluid">
                                   <h3>ขั้นตอน 2</h3><br>
                                    <h4>ในหน้าสินค้าทำการเลือกสินค้าที่ต้องการกดสั่งซื้อ</h4></div>
                            	<div class="col-12 col-md-4 my-3">
                                	<img src="../../images/cart.png"  width="150" height="150"class="img-fluid">
                                    <h3>ขั้นตอน 3</h3><br>
                                    <h4>ทำการเลือกจำนวนและกดใส่ตะกร้าสินค้า</h4> </div><br>
								<div class="col-12 col-md-4 my-3">
                                	<img src="../../images/1.png"  width="150" height="150"class="img-fluid">
                                    <h3>ขั้นตอน 4</h3><br>
                                    <h4>ตรวจสอบรายการสินค้าและยืนยันการสั่งซื้อ</h4> </div><br>
                            	<div class="col-12 col-md-4 my-3">
                                	<img src="../../images/pay.png"  width="150" height="150" class="img-fluid">
                                    <h3>ขั้นตอน 5</h3><br>
                                    <h4>ทำการชำระเงินและกรอกหลักฐานการชำระเงิน (ในหน้า PAYMENT CONFIRMATION)</h4></div>
								
                            	<div class="col-12 col-md-4 px-md-0 my-3">
                                	<img src="../../images/shipping.png"  width="150" height="150" class="img-fluid">
                                    <h3>ขั้นตอน 6</h3><br>
                                    <h4>หลังจากทางร้านได้รับชำระเงินค่าสินค้าเรียบร้อยแล้วบริษัทจะส่งสินค้าออกภายใน 1-3 วันทำการ</h4></div>
						
                        
                         
                        </div>
                       

                        
                    </div>
		</div>
		
	</div>
    <br/>
 <?php include('footer.php');?>
