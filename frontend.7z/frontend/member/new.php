<?php include('header.php'); ?>



<!--content-->
<div class="contact">

    <div class="container">

        <div class="contact-form">

            <!DOCTYPE html>
            <html lang="en">

            <head>
                <meta charset="UTF-8">
                <meta http-equiv="X-UA-Compatible" content="IE=edge">
                <meta name="viewport" content="width=device-width, initial-scale=1.0">
                <title></title>
                <link rel="stylesheet" href="">
            </head>

            <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
 <div class="w3-content w3-section" style="max-width:1400px">
 	<img class="mySlides" src="../../slide/slide1.jpg" style="width:100%">
 	<img class="mySlides" src="../../slide/slide2.jpeg" style="width:100%">
 	<img class="mySlides" src="../../slide/slide3.jpeg" style="width:100%">
    
 </div>



 <script>
 	var myIndex = 0;
 	carousel();

 	function carousel() {
 		var i;
 		var x = document.getElementsByClassName("mySlides");
 		for (i = 0; i < x.length; i++) {
 			x[i].style.display = "none";
 		}
 		myIndex++;
 		if (myIndex > x.length) {
 			myIndex = 1
 		}
 		x[myIndex - 1].style.display = "block";
 		setTimeout(carousel, 3000); // Change image every 2 seconds
 	}
 </script>
 <!--content-->
 <div class="content">
 	<div class="container">
 		<div class="content-top">

            <body>
                <center>
                <h4>Top 10 favorite designer bags! เปิดกรุกระเป๋าแบรนด์อัพเดทใช้แล้วชอบ ใบไหนน่าโดนมาดู!! ✨ | Brinkkty</h4>    
                <iframe width="1000" height="500" src="https://www.youtube.com/embed/AUnmI-h8WnU" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe><br>
<br>
<br>
                <h4>Haul เปิดกรุกระเป๋าแบรนด์เนมที่ชอบ ใบไหนปัง มามุงกัน | itim’s review</h4>
                <iframe width="1000" height="500" src="https://www.youtube.com/embed/Xb_GsWUX8Zo" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe><br>
<br>
<br>
                <h4>เปิดกรุกระเป๋า 2022 รีวิวกระเป๋าอย่างละเอียด | Khwankhong</h4>
                <iframe width="1000" height="500" src="https://www.youtube.com/embed/1bAQJ9uZqas" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe></center>
            </body>

            </html>






            <div class="clearfix"> </div>
        </div>

    </div>

</div>
<br />
<?php include('footer.php'); ?>