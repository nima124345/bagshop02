<div class="footer">
	<div class="container">
		<div class="footer-top-at">
			<div class="col-md-4 amet-sed">
				<h4>ข้อมูลเพิ่มเติม</h4>
				<ul class="nav-bottom">
					<li><a href="howto.php">วิธีการสั่งซื้อ</a></li>
					<li><a href="return.php">การส่งคืนสินค้า</a></li>
					<li><a href="register.php">การสมัครสมาชิก</a></li>

				</ul>	
			</div>

			<div class="col-md-4 amet-sed ">
				<h4>ติดต่อเรา</h4>
				<p>454 ซ.อ่อนนุช36 ถ.สุขุมวิท77 เขตสวนหลวง แขวงสวนหลวง กรุงเทพฯ 10250</p>
				<p>ติดต่อสอบถาม</p>
				<p>โทร: 098-275-7082</p>
				<ul class="social">
					<li><a href="#"><i> </i></a></li>						
					<li><a href="#"><i class="twitter"> </i></a></li>
					<li><a href="#"><i class="rss"> </i></a></li>
					<li><a href="#"><i class="gmail"> </i></a></li>	
				</ul>
			</div>
			
			<div class="clearfix"> </div>
		</div>
	</div>
	
	<div class="footer-class" style="color:white">
			© 2023 New store All Rights Reserved | Welcome to Bagshop
	</div>
</div>