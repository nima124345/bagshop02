<?php include('header.php');?>

<!--content-->
<div class="contact">	
	<div class="container">
		<h1>CONTACT US</h1>
		<div class="contact-form">
		<!-- <div class="col-md-8 contact-grid">
				<?=$company_map;?>
			</div> -->
			
			<div class="col-md-12 contact-in">
				<div class="address-more">
					<p><b>ที่อยู่</b></p>
                        
					<!-- <p><a href="index.php"><img src="../../image/logobagshop.png" alt=""></a></p> -->
					<p>454 ซ.อ่อนนุช36 ถ.สุขุมวิท77 เขตสวนหลวง แขวงสวนหลวง กทม. 10250</p><br>
					<p><b>ติดต่อสอบถาม</b></p>
					<p>โทร: 098-275-7082</p><br>

					<center><iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3876.221160200597!2d100.62080411328553!3d13.705051002071222!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x311d601f25dee615%3A0x1dce5986b9d51311!2zNDU0IOC4i-C4reC4oiDguK3guYjguK3guJnguJnguLjguIogMzYg4LmB4LiC4Lin4LiHIOC4quC4p-C4meC4q-C4peC4p-C4hyDguYHguILguKfguIfguKrguKfguJnguKvguKXguKfguIcg4LiB4Lij4Li44LiH4LmA4LiX4Lie4Lih4Lir4Liy4LiZ4LiE4LijIDEwMjUw!5e0!3m2!1sth!2sth!4v1560246486189!5m2!1sth!2sth" width="600" height="450" frameborder="0" style="border:0" allowfullscreen></iframe></center>
				</div>

				<div class="address-more"></div>
			</div>
				
			<div class="clearfix"> </div>
		</div>	
	</div>
</div><br>

<?php include('footer.php');?>