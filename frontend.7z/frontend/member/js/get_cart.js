$(function() {
    function getCart(id) {
        alert(id);
    }

});