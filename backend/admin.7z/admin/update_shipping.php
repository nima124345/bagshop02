<?php include('header.php'); ?>
<div class="right_col" role="main">
    <div class="row">
        <div class="col-md-12 col-sm-12 col-xs-12">
            <div class="x_panel">
                <div class="x_title">
                    <h3>แก้ไขข้อมูลการจัดสั่ง</h3>
                    <ul class="nav navbar-right panel_toolbox">
                        <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a> </li>
                        <li><a class="close-link"><i class="fa fa-close"></i></a> </li>
                    </ul>
                    <div class="clearfix"></div>
                </div>
                <div class="x_content">
                    <br />
                    <?php
                    if (isset($_GET['id'])) {
                        $id = $_GET['id'];
                        $sql = " select *  from tb_shipping";
                        $sql .= " where";
                        $sql .= " shipping_id=$id";
                        $result = $cls_conn->select_base($sql);
                        while ($row = mysqli_fetch_array($result)) {
                            $shipping_id = $row['shipping_id'];
                            $order_id = $row['order_id'];
                            $shipping_trackingno = $row['shipping_trackingno'];
                            $ship_address=$rowu['ship_address'];
                            $ship_tumbol=$rowu['ship_tumbol'];
                            $ship_amphur=$rowu['ship_amphur'];
                            $ship_province=$rowu['ship_province'];
                            $ship_postcode=$rowu['ship_postcode'];
                            $shipping_by = $row['shipping_by'];
                            $shipping_cost = $row['shipping_cost'];
                            $member_id = $row['member_id'];
                            $shipping_status = $row['shipping_status'];
                            $shipping_datetime = $row['shipping_datetime'];
                        }
                    }
                    ?>
                    <form id="demo-form2" data-parsley-validate class="form-horizontal form-label-left" method="post">
                        <input type="hidden" name="shipping_id" value="<?= $shipping_id; ?>" />

                        <div class="form-group">
                            <label class="control-label col-md-3 col-sm-3 col-xs-12" for="order_id">รหัสคำสั่งซื้อ<span class="required">:</span> </label>
                            <div class="col-md-6 col-sm-6 col-xs-12">
                                <select id="order_id" name="order_id" value="<?=$order_id;?>" required="required" class="form-control col-md-7 col-xs-12">
                                    <option value="">--เลือก--</option>
                                    <?php
                                    $sql = " select * from tb_order";
                                    $result = $cls_conn->select_base($sql);
                                    while ($row = mysqli_fetch_array($result)) {
                                    ?>
                                        <option value="<?= $row['order_id']; ?>"><?= $row['order_no']; ?>
                                        </option>
                                    <?php
                                    }
                                    ?>
                                </select>
                            </div>
                        </div>

                        <div class="form-group">
                            <label class="control-label col-md-3 col-sm-3 col-xs-12" for="shipping_trackingno">เลขพัสดุ<span class="required">:</span> </label>
                            <div class="col-md-6 col-sm-6 col-xs-12">
                                <input type="text" id="shipping_trackingno" name="shipping_trackingno" value="<?=$shipping_trackingno;?>" required="required" class="form-control col-md-7 col-xs-12">
                            </div>
                        </div>

                        <div class="form-group">
                            <label class="control-label col-md-3 col-sm-3 col-xs-12" for="ship_address">ที่อยู่<span class="required">:</span> </label>
                            <div class="col-md-6 col-sm-6 col-xs-12">
                                <input type="text" id="ship_address" name="ship_address"  value="<?=$ship_address;?>" required="required" class="form-control col-md-7 col-xs-12"> </div>
                        </div>

                        <div class="form-group">
                            <label class="control-label col-md-3 col-sm-3 col-xs-12" for="ship_tumbol">ตำบล<span class="required">:</span> </label>
                            <div class="col-md-6 col-sm-6 col-xs-12">
                                <input type="text" id="ship_tumbol" name="ship_tumbol"  value="<?=$ship_tumbol;?>" required="required" class="form-control col-md-7 col-xs-12"> </div>
                        </div>

                        <div class="form-group">
                            <label class="control-label col-md-3 col-sm-3 col-xs-12" for="ship_amphur">อำเภอ<span class="required">:</span> </label>
                            <div class="col-md-6 col-sm-6 col-xs-12">
                                <input type="text" id="ship_amphur" name="ship_amphur"  value="<?=$ship_amphur;?>" required="required" class="form-control col-md-7 col-xs-12"> </div>
                        </div>

                        <div class="form-group">
                            <label class="control-label col-md-3 col-sm-3 col-xs-12" for="ship_province">จังหวัด<span class="required">:</span> </label>
                            <div class="col-md-6 col-sm-6 col-xs-12">
                                <input type="text" id="ship_province" name="ship_province"  value="<?=$ship_province;?>" required="required" class="form-control col-md-7 col-xs-12"> </div>
                        </div>

                        <div class="form-group">
                            <label class="control-label col-md-3 col-sm-3 col-xs-12" for="ship_postcode">รหัสไปรษณีย์<span class="required">:</span> </label>
                            <div class="col-md-6 col-sm-6 col-xs-12">
                                <input type="text" id="ship_postcode" name="ship_postcode"  value="<?=$ship_postcode;?>" required="required" class="form-control col-md-7 col-xs-12"> </div>
                        </div>

                        <div class="form-group">
                            <label class="control-label col-md-3 col-sm-3 col-xs-12" for="shipping_by">ผู้จัดส่ง<span class="required">:</span> </label>
                            <div class="col-md-6 col-sm-6 col-xs-12">
                                <input type="text" id="shipping_by" name="shipping_by" value="<?=$shipping_by;?>" required="required" class="form-control col-md-7 col-xs-12">
                            </div>
                        </div>


                        <div class="form-group">
                            <label class="control-label col-md-3 col-sm-3 col-xs-12" for="shipping_cost">ค่าจัดส่ง<span class="required">:</span> </label>
                            <div class="col-md-6 col-sm-6 col-xs-12">
                                <input type="text" id="shipping_cost" name="shipping_cost" value="<?=$shipping_cost;?>" required="required" class="form-control col-md-7 col-xs-12">
                            </div>
                        </div>

                      
                        <div class="form-group">
                            <label class="control-label col-md-3 col-sm-3 col-xs-12" for="member_id">รหัสสมาชิก<span class="required">:</span> </label>
                            <div class="col-md-6 col-sm-6 col-xs-12">
                               <select  id="member_id" name="member_id" value="<?=$member_id;?>" required="required" class="form-control col-md-7 col-xs-12"> 
                                    <?php
                                        $sqld=" select * from tb_member";
                                        $resultd=$cls_conn->select_base($sqld);
                                        while($rowd=mysqli_fetch_array($resultd))
                                        {
                                            ?>
                                        <option value="<?=$rowd['member_id'];?>"><?=$rowd['member_id'];?> : <?=$rowd['member_fullname'];?></option>
                                         <?php
                                        }
                                    ?>
                                </select> </div>
                        </div>


                        <div class="form-group">
                            <label class="control-label col-md-3 col-sm-3 col-xs-12" for="shipping_status">สถานะการจัดสั่ง<span class="required">:</span> </label>
                            <div class="col-md-6 col-sm-6 col-xs-12">
                                <select id="shipping_status" name="shipping_status" value="<?=$shipping_status;?>" required="required" class="form-control col-md-7 col-xs-12">
                                    <option value="">--กรุณาเลือกสถานะการจัดสั่ง--</option>
                                    <option value="shipping">รอจัดส่ง</option>
                                    <option value="shipped">จัดส่งเรียบร้อย</option>
                                </select>
                            </div>
                        </div>

                        <div class="form-group">
                            <label class="control-label col-md-3 col-sm-3 col-xs-12" for="shipping_datetime">วันที่จัดส่ง<span class="required">:</span> </label>
                            <div class="col-md-6 col-sm-6 col-xs-12">
                                <input type="datetime-local" id="shipping_datetime" name="shipping_datetime" value="<?=$shipping_datetime;?>" required="required" class="form-control col-md-7 col-xs-12">
                            </div>
                        </div>

                        <div class="ln_solid"></div>
                        <div class="form-group">
                            <div class="col-md-6 col-sm-6 col-xs-12 col-md-offset-3">
                                <button type="submit" name="submit" class="btn btn-success">แก้ไข</button>
                                <button type="reset" name="reset" class="btn btn-danger">ยกเลิก</button>
                            </div>
                        </div>
                    </form>
                    <?php
                    if (isset($_POST['submit'])) {
                        $shipping_id = $_POST['shipping_id'];
                        $order_id = $_POST['order_id'];
                        $shipping_trackingno = $_POST['shipping_trackingno'];
                        $ship_address=$_POST['ship_address'];
                        $ship_tumbol=$_POST['ship_tumbol'];
                        $ship_amphur=$_POST['ship_amphur'];
                        $ship_province=$_POST['ship_province'];
                        $ship_postcode=$_POST['ship_postcode'];
                        $shipping_by = $_POST['shipping_by'];
                        $shipping_cost = $_POST['shipping_cost'];
                        $member_id = $_POST['member_id'];
                        $shipping_status = $_POST['shipping_status'];
                        $shipping_datetime = $_POST['shipping_datetime'];


                        $sql = " update tb_shipping";
                        $sql .= " set";
                        $sql .= " order_id='$order_id'";
                        $sql .= " ,shipping_trackingno='$shipping_trackingno'";
                        $sql.=" ,ship_address='$ship_address'";
                        $sql.=" ,ship_tumbol='$ship_tumbol'";
                        $sql.=" ,ship_amphur='$ship_amphur'";
                        $sql.=" ,ship_province='$ship_province'";
                        $sql.=" ,ship_postcode='$ship_postcode'";
                        $sql .= " ,shipping_by='$shipping_by'";
                        $sql .= " ,shipping_cost='$shipping_cost'";
                        $sql .= " ,member_id='$member_id'";
                        $sql .= " ,shipping_status='$shipping_status'";
                        $sql .= " ,shipping_datetime='$shipping_datetime'";
                        $sql .= " where";
                        $sql .= " shipping_id=$shipping_id";

                        if ($cls_conn->write_base($sql) == true) {
                            echo $cls_conn->show_message('แก้ไขข้อมูลสำเร็จ');
                            echo $cls_conn->goto_page(1, 'show_shipping.php');
                        } else {
                            echo $cls_conn->show_message('แก้ไขข้อมูลไม่สำเร็จ');
                            echo $sql;
                        }
                    }

                    ?>



                </div>
            </div>
        </div>
    </div>
</div>
<?php include('footer.php'); ?>