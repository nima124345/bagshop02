<?php include('header.php');?>
<div class="right_col" role="main">
         

           
</div>
<?php include('footer.php');?>
