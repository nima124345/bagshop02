<?php include('header.php'); ?>
<div class="right_col" role="main">
    <div class="row">
        <div class="col-md-12 col-sm-12 col-xs-12">
            <div class="x_panel">
                <div class="x_title">
                    <h3>แก้ไขข้อมูลพรีออเดอร์</h3>
                    <ul class="nav navbar-right panel_toolbox">
                        <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a> </li>
                        <li><a class="close-link"><i class="fa fa-close"></i></a> </li>
                    </ul>
                    <div class="clearfix"></div>
                </div>
                <div class="x_content">
                    <br />
                    <?php
                    if (isset($_GET['id'])) 
                    {
                        $id = $_GET['id'];
                        $sql = " select *  from tb_preorder";
                        $sql .= " where";
                        $sql .= " preorder_id=$id";
                        $result = $cls_conn->select_base($sql);
                        while ($row = mysqli_fetch_array($result)) 
                        {
                            $preorder_id = $row['preorder_id'];
                            $preorder_no = $_row['preorder_no'];
                            $preorder_price = $_row['preorder_price'];
                            $member_id = $_row['member_id'];
                            $preorder_status = $_row['preorder_status'];
                            $preorder_datetime = $_row['preorder_datetime'];
                        }
                    }
                    ?>
                    <form id="demo-form2" data-parsley-validate class="form-horizontal form-label-left" method="post">
                        <input type="hidden" name="preorder_id" value="<?= $preorder_id; ?>" />

                        <div class="form-group">
                            <label class="control-label col-md-3 col-sm-3 col-xs-12" for="preorder_no">หมายเลขพรีออเดอร์<span class="required">:</span> </label>
                            <div class="col-md-6 col-sm-6 col-xs-12">
                                <input type="text" id="preorder_no" name="preorder_no" value="<?=$preorder_no;?>" required="required" class="form-control col-md-7 col-xs-12">
                            </div>
                        </div>

                        <div class="form-group">
                            <label class="control-label col-md-3 col-sm-3 col-xs-12" for="preorder_price">ราคาพรีออเดอร์<span class="required">:</span> </label>
                            <div class="col-md-6 col-sm-6 col-xs-12">
                                <input type="text" id="preorder_price" name="preorder_price" value="<?=$preorder_price;?>" required="required" class="form-control col-md-7 col-xs-12">
                            </div>
                        </div>


                        <div class="form-group">
                            <label class="control-label col-md-3 col-sm-3 col-xs-12" for="member_id">รหัสสมาชิก<span class="required">:</span> </label>
                            <div class="col-md-6 col-sm-6 col-xs-12">
                               <select  id="member_id" name="member_id" value="<?=$member_id;?>" required="required" class="form-control col-md-7 col-xs-12"> 
                                    <?php
                                        $sqld=" select * from tb_member";
                                        $resultd=$cls_conn->select_base($sqld);
                                        while($rowd=mysqli_fetch_array($resultd))
                                        {
                                            ?>
                                        <option value="<?=$rowd['member_id'];?>"><?=$rowd['member_id'];?> : <?=$rowd['member_fullname'];?></option>
                                         <?php
                                        }
                                    ?>
                                </select> </div>
                        </div>

                        <div class="form-group">
                            <label class="control-label col-md-3 col-sm-3 col-xs-12" for="product_status">สถานะสินค้า*<span class="required">*</span> </label>
                            <div class="col-md-6 col-sm-6 col-xs-12">
                                <select id="product_status" name="product_status" required="required" class="form-control col-md-7 col-xs-12">
                                    <option value=""selected>--กรุณาเลือกสถานะสินค้า--</option>
                                    <option value="in stock">พร้อมส่ง</option>
                                    <option value="Preorder">พรีออเดอร์</option>

                                </select>
                            </div>
                        </div>

                        <div class="form-group">
                            <label class="control-label col-md-3 col-sm-3 col-xs-12" for="preorder_datetime">วันที่พรีออเดอร์<span class="required">:</span> </label>
                            <div class="col-md-6 col-sm-6 col-xs-12">
                                <input type="datetime-local" id="preorder_datetime" name="preorder_datetime" value="<?=$preorder_datetime;?>" required="required" class="form-control col-md-7 col-xs-12">
                            </div>
                        </div>

                        <div class="ln_solid"></div>
                        <div class="form-group">
                            <div class="col-md-6 col-sm-6 col-xs-12 col-md-offset-3">
                                <button type="submit" name="submit" class="btn btn-success">แก้ไข</button>
                                <button type="reset" name="reset" class="btn btn-danger">ยกเลิก</button>
                            </div>
                        </div>
                        
                    </form>
                    <?php
                    if (isset($_POST['submit'])) {
                        $preorder_id = $_POST['preorder_id'];
                        $preorder_no = $_POST['preorder_no'];
                        $preorder_price = $_POST['preorder_price'];
                        $member_id = $_POST['member_id'];
                        $preorder_status = $_POST['preorder_status'];
                        $preorder_datetime = $_POST['preorder_datetime'];

                        $sql = " update tb_preorder";
                        $sql .= " set";
                        $sql .= " preorder_no='$preorder_no'";
                        $sql .= " ,preorder_price='$preorder_price'";
                        $sql .= " ,member_id='$member_id'";
                        $sql .= " ,preorder_status='$preorder_status'";
                        $sql .= " ,preorder_datetime='$preorder_datetime'";
                        $sql .= " where";
                        $sql .= " preorder_id=$preorder_id";

                        if ($cls_conn->write_base($sql) == true) {
                            echo $cls_conn->show_message('แก้ไขข้อมูลสำเร็จ');
                            echo $cls_conn->goto_page(1, 'show_preorder.php');
                        } else {
                            echo $cls_conn->show_message('แก้ไขข้อมูลไม่สำเร็จ');
                            echo $sql;
                        }
                    }

                    ?>



                </div>
            </div>
        </div>
    </div>
</div>
<?php include('footer.php'); ?>