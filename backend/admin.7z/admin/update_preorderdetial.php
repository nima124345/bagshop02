<?php include('header.php'); ?>
<div class="right_col" role="main">
    <div class="row">
        <div class="col-md-12 col-sm-12 col-xs-12">
            <div class="x_panel">
                <div class="x_title">
                    <h3>แก้ไขข้อมูลรายละเอียดการพรีออเดอร์</h3>
                    <ul class="nav navbar-right panel_toolbox">
                        <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a> </li>
                        <li><a class="close-link"><i class="fa fa-close"></i></a> </li>
                    </ul>
                    <div class="clearfix"></div>
                </div>
                <div class="x_content">
                    <br />
                    <?php
                    if (isset($_GET['id'])) {
                        $id = $_GET['id'];
                        $sql = " select *  from tb_preorderdetial";
                        $sql .= " where";
                        $sql .= " preorderdetial_id=$id";
                        $result = $cls_conn->select_base($sql);
                        while ($row = mysqli_fetch_array($result)) {
                            $preorderdetial_id = $row['preorderdetial_id'];
                            $preorder_id = $row['preorder_id'];
                            $product_id = $row['product_id'];
                            $member_id = $row['member_id'];
                            $preorderdetial_qty = $row['preorderdetial_qty'];
                            $preorderdetial_price = $row['preorderdetial_price'];
                            $preorderdetial_status = $row['preorderdetial_status'];
                            $preorderdetial_datetime = $row['preorderdetial_datetime'];
                        }
                    }
                    ?>
                    <form id="demo-form2" data-parsley-validate class="form-horizontal form-label-left" method="post">
                        <input type="hidden" name="preorderdetial_id" value="<?= $preorderdetial_id; ?>" />

                        <div class="form-group">
                            <label class="control-label col-md-3 col-sm-3 col-xs-12" for="preorder_id">รหัสพรีออเดอร์<span class="required">:</span> </label>
                            <div class="col-md-6 col-sm-6 col-xs-12">
                                <select id="preorder_id" name="preorder_id" value="<?=$preorder_id;?>" required="required" class="form-control col-md-7 col-xs-12">
                                    <option value="">--เลือก--</option>
                                    <?php
                                    $sql = " select * from tb_preorder";
                                    $result = $cls_conn->select_base($sql);
                                    while ($row = mysqli_fetch_array($result)) {
                                    ?>
                                        <option value="<?= $row['preorder_id']; ?>"><?= $row['preorder_no']; ?>
                                        </option>
                                    <?php
                                    }
                                    ?>
                                </select>
                            </div>
                        </div>

                        <div class="form-group">
                            <label class="control-label col-md-3 col-sm-3 col-xs-12" for="product_id">รหัสสินค้า<span class="required">:</span> </label>
                            <div class="col-md-6 col-sm-6 col-xs-12">
                                <select id="product_id" name="product_id" value="<?=$product_id;?>" required="required" class="form-control col-md-7 col-xs-12">
                                    <option value="">--เลือก--</option>
                                    <?php
                                    $sql = " select * from tb_product";
                                    $result = $cls_conn->select_base($sql);
                                    while ($row = mysqli_fetch_array($result)) {
                                    ?>
                                        <option value="<?= $row['product_id']; ?>"><?= $row['product_id']; ?>  : <?= $row['product_name']; ?>
                                        </option>
                                    <?php
                                    }
                                    ?>
                                </select>
                            </div>
                        </div>

                        <div class="form-group">
                            <label class="control-label col-md-3 col-sm-3 col-xs-12" for="member_id">รหัสสมาชิก<span class="required">*</span> </label>

                            <div class="form-group">
                            <label class="control-label col-md-3 col-sm-3 col-xs-12" for="member_id">รหัสสมาชิก<span class="required">:</span> </label>
                            <div class="col-md-6 col-sm-6 col-xs-12">
                               <select  id="member_id" name="member_id" value="<?=$member_id;?>" required="required" class="form-control col-md-7 col-xs-12"> 
                                    <?php
                                        $sqld=" select * from tb_member";
                                        $resultd=$cls_conn->select_base($sqld);
                                        while($rowd=mysqli_fetch_array($resultd))
                                        {
                                            ?>
                                        <option value="<?=$rowd['member_id'];?>"><?=$rowd['member_id'];?> : <?=$rowd['member_fullname'];?></option>
                                         <?php
                                        }
                                    ?>
                                </select> </div>
                        </div>

                        <div class="form-group">
                            <label class="control-label col-md-3 col-sm-3 col-xs-12" for="preorderdetial_qty">จำนวนรายละเอียดการพรีออเดอร์<span class="required">:</span> </label>
                            <div class="col-md-6 col-sm-6 col-xs-12">
                                <input type="text" id="preorderdetial_qty" name="preorderdetial_qty" value="<?=$preorderdetial_qty;?>" required="required" class="form-control col-md-7 col-xs-12">
                            </div>
                        </div>

                        <div class="form-group">
                            <label class="control-label col-md-3 col-sm-3 col-xs-12" for="preorderdetial_price">ราคา<span class="required">:</span> </label>
                            <div class="col-md-6 col-sm-6 col-xs-12">
                                <input type="number" id="preorderdetial_price" name="preorderdetial_price" value="<?=$preorderdetial_price;?>" required="required" class="form-control col-md-7 col-xs-12">
                            </div>
                        </div>

                        <div class="form-group">
                            <label class="control-label col-md-3 col-sm-3 col-xs-12" for="preorderdetial_status">สถานะรายละเอียดการพรีออเดอร์<span class="required">:</span> </label>
                            <div class="col-md-6 col-sm-6 col-xs-12">
                                <input type="text" id="preorderdetial_status" name="preorderdetial_status" value="<?=$preorderdetial_status;?>" required="required" class="form-control col-md-7 col-xs-12">
                            </div>
                        </div>

                        <div class="form-group">
                            <label class="control-label col-md-3 col-sm-3 col-xs-12" for="preorderdetial_datetime">วันที่<span class="required">:</span> </label>
                            <div class="col-md-6 col-sm-6 col-xs-12">
                                <input type="datetime-local" id="preorderdetial_datetime" name="preorderdetial_datetime" value="<?=$preorderdetial_datetime;?>" required="required" class="form-control col-md-7 col-xs-12">
                            </div>
                        </div>

                            <div class="ln_solid"></div>
                            <div class="form-group">
                                <div class="col-md-6 col-sm-6 col-xs-12 col-md-offset-3">
                                    <button type="submit" name="submit" class="btn btn-success">แก้ไข</button>
                                    <button type="reset" name="reset" class="btn btn-danger">ยกเลิก</button>
                                </div>
                            </div>
                    </form>
                    <?php
                    if (isset($_POST['submit'])) {
                        $preorderdetial_id = $_POST['preorderdetial_id'];
                        $preorder_id = $_POST['preorder_id'];
                        $product_id = $_POST['product_id'];
                        $member_id = $_POST['member_id'];
                        $preorderdetial_qty = $_POST['preorderdetial_qty'];
                        $preorderdetial_price = $_POST['preorderdetial_price'];
                        $preorderdetial_status = $_POST['preorderdetial_status'];
                        $preorderdetial_datetime = $_POST['preorderdetial_datetime'];


                        $sql = " update tb_preorderdetial";
                        $sql .= " set";
                        $sql .= " preorder_id='$preorder_id'";
                        $sql .= " ,product_id='$product_id'";
                        $sql .= " ,member_id='$member_id'";
                        $sql .= " ,preorderdetial_qty='$preorderdetial_qty'";
                        $sql .= " ,preorderdetial_price='$preorderdetial_price'";
                        $sql .= " ,preorderdetial_status='$preorderdetial_status'";
                        $sql .= " ,preorderdetial_datetime='$preorderdetial_datetime'";
                        $sql .= " where";
                        $sql .= " preorderdetial_id=$preorderdetial_id";

                        if ($cls_conn->write_base($sql) == true) {
                            echo $cls_conn->show_message('แก้ไขข้อมูลสำเร็จ');
                            echo $cls_conn->goto_page(1, 'show_preorderdetial.php');
                        } else {
                            echo $cls_conn->show_message('แก้ไขข้อมูลไม่สำเร็จ');
                            echo $sql;
                        }
                    }

                    ?>



                </div>
            </div>
        </div>
    </div>
</div>
<?php include('footer.php'); ?>