<?php include('header.php'); ?>
<div class="right_col" role="main">
    <div class="row">
        <div class="col-md-12 col-sm-12 col-xs-12">
            <div class="x_panel">
                <div class="x_title">
                    <h3>แก้ไขข้อมูล การรับคืนสินค้า</h3>
                    <ul class="nav navbar-right panel_toolbox">
                        <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a> </li>
                        <li><a class="close-link"><i class="fa fa-close"></i></a> </li>
                    </ul>
                    <div class="clearfix"></div>
                </div>
                <div class="x_content">
                    <br />
                    <?php
                    if (isset($_GET['id'])) {
                        $id = $_GET['id'];
                        $sql = " select *  from tb_return";
                        $sql .= " where";
                        $sql .= " return_id=$id";
                        $result = $cls_conn->select_base($sql);
                        while ($row = mysqli_fetch_array($result)) {
                            $return_id = $row['return_id'];
                            $order_id = $row['order_id'];
                            $return_remark = $row['return_remark'];
                            $product_id = $row['product_id'];
                            $return_qty = $row['return_qty'];
                            $member_id = $row['member_id'];
                            $paymeny_id = $row['paymeny_id'];
                            $return_datetime = $row['return_datetime'];
                        }
                    }
                    ?>
                    <form id="demo-form2" data-parsley-validate class="form-horizontal form-label-left" method="post">
                        <input type="hidden" name="return_id" value="<?= $return_id; ?>" />

                        <div class="form-group">
                            <label class="control-label col-md-3 col-sm-3 col-xs-12" for="order_id">รหัสคำสั่งซื้อ<span class="required">:</span> </label>
                            <div class="col-md-6 col-sm-6 col-xs-12">
                                <select id="order_id" name="order_id" value="<?=$order_id;?>" required="required" class="form-control col-md-7 col-xs-12">
                                    <option value="">--เลือก--</option>
                                    <?php
                                    $sql = " select * from tb_order";
                                    $result = $cls_conn->select_base($sql);
                                    while ($row = mysqli_fetch_array($result)) {
                                    ?>
                                        <option value="<?= $row['order_id']; ?>"><?= $row['product_price']; ?>
                                        </option>
                                    <?php
                                    }
                                    ?>
                                </select>
                            </div>
                        </div>


                        <div class="form-group">
                            <label class="control-label col-md-3 col-sm-3 col-xs-12" for="return_remark">หมายเหตุ<span class="required">:</span> </label>
                            <div class="col-md-6 col-sm-6 col-xs-12">
                                <input type="text" id="return_remark" name="return_remark" value="<?=$return_remark;?>" required="required" class="form-control col-md-7 col-xs-12">
                            </div>
                        </div>


                        <div class="form-group">
                            <label class="control-label col-md-3 col-sm-3 col-xs-12" for="product_id">รหัสสินค้า<span class="required">:</span> </label>
                            <div class="col-md-6 col-sm-6 col-xs-12">
                                <select id="product_id" name="product_id" value="<?=$product_id;?>" required="required" class="form-control col-md-7 col-xs-12">
                                    <option value="">--เลือก--</option>
                                    <?php
                                    $sql = " select * from tb_product";
                                    $result = $cls_conn->select_base($sql);
                                    while ($row = mysqli_fetch_array($result)) {
                                    ?>
                                        <option value="<?= $row['product_id']; ?>"><?= $row['product_name']; ?>
                                        </option>
                                    <?php
                                    }
                                    ?>
                                </select>
                            </div>
                        </div>

                        <div class="form-group">
                            <label class="control-label col-md-3 col-sm-3 col-xs-12" for="return_qty">จำนวนสินค้าที่คืน<span class="required">:</span> </label>
                            <div class="col-md-6 col-sm-6 col-xs-12">
                                <input type="number" id="return_qty" name="return_qty" value="<?=$return_qty;?>" required="required" class="form-control col-md-7 col-xs-12">
                            </div>
                        </div>

                        <div class="form-group">
                            <label class="control-label col-md-3 col-sm-3 col-xs-12" for="member_id">รหัสสมาชิก<span class="required">:</span> </label>
                            <div class="col-md-6 col-sm-6 col-xs-12">
                               <select  id="member_id" name="member_id" value="<?=$member_id;?>" required="required" class="form-control col-md-7 col-xs-12"> 
                                    <?php
                                        $sqld=" select * from tb_member";
                                        $resultd=$cls_conn->select_base($sqld);
                                        while($rowd=mysqli_fetch_array($resultd))
                                        {
                                            ?>
                                        <option value="<?=$rowd['member_id'];?>"><?=$rowd['member_id'];?> : <?=$rowd['member_fullname'];?></option>
                                         <?php
                                        }
                                    ?>
                                </select> </div>
                        </div>


                        <div class="form-group">
                            <label class="control-label col-md-3 col-sm-3 col-xs-12" for="paymeny_id">รหัสการชำระเงิน<span class="required">:</span> </label>
                            <div class="col-md-6 col-sm-6 col-xs-12">
                               <select  id="paymeny_id" name="paymeny_id" value="<?=$paymeny_id;?>" required="required" class="form-control col-md-7 col-xs-12"> 
                                    <?php
                                        $sqld=" select * from tb_member";
                                        $resultd=$cls_conn->select_base($sqld);
                                        while($rowd=mysqli_fetch_array($resultd))
                                        {
                                            ?>
                                        <option value="<?=$rowd['paymeny_id'];?>"> : <?=$rowd['paymeny_price'];?></option>
                                         <?php
                                        }
                                    ?>
                                </select> </div>
                        </div>

                        <div class="form-group">
                            <label class="control-label col-md-3 col-sm-3 col-xs-12" for="return_datetime">วันที่คืนสินค้า<span class="required">:</span> </label>
                            <div class="col-md-6 col-sm-6 col-xs-12">
                                <input type="datetime-local" id="return_datetime" name="return_datetime" value="<?=$return_datetime;?>" required="required" class="form-control col-md-7 col-xs-12">
                            </div>
                        </div>

                        <div class="ln_solid"></div>
                        <div class="form-group">
                            <div class="col-md-6 col-sm-6 col-xs-12 col-md-offset-3">
                                <button type="submit" name="submit" class="btn btn-success">แก้ไข</button>
                                <button type="reset" name="reset" class="btn btn-danger">ยกเลิก</button>
                            </div>
                        </div>
                    </form>
                    <?php
                    if (isset($_POST['submit'])) {
                        $return_id = $_POST['return_id'];
                        $order_id = $_POST['order_id'];
                        $return_remark = $_POST['return_remark'];
                        $product_id = $_POST['product_id'];
                        $return_qty = $_POST['return_qty'];
                        $member_id = $_POST['member_id'];
                        $paymeny_id = $_POST['paymeny_id'];
                        $return_datetime = $_POST['return_datetime'];


                        $sql = " update tb_return";
                        $sql .= " set";
                        $sql .= " order_id='$order_id'";
                        $sql .= " ,return_remark='$return_remark'";
                        $sql .= " ,product_id='$product_id'";
                        $sql .= " ,return_qty='$return_qty'";
                        $sql .= " ,member_id='$member_id'";
                        $sql .= " ,paymeny_id='$paymeny_id'";
                        $sql .= " ,return_datetime='$return_datetime'";
                        $sql .= " where";
                        $sql .= " return_id=$return_id";

                        if ($cls_conn->write_base($sql) == true) {
                            echo $cls_conn->show_message('แก้ไขข้อมูลสำเร็จ');
                            echo $cls_conn->goto_page(1, 'show_return.php');
                        } else {
                            echo $cls_conn->show_message('แก้ไขข้อมูลไม่สำเร็จ');
                            echo $sql;
                        }
                    }

                    ?>



                </div>
            </div>
        </div>
    </div>
</div>
<?php include('footer.php'); ?>